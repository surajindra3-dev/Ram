package com.focuslock.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import android.graphics.Color

class BlockedActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var message: TextView
    private val tick = object : Runnable {
        override fun run() {
            if (!FocusStore.isActive(this@BlockedActivity)) { FocusStore.awardIfFinished(this@BlockedActivity); finish(); return }
            val ms = FocusStore.remainingMs(this@BlockedActivity)
            message.text = "This app is paused by Strict Mode.\n\nTime remaining: ${ms / 60_000}m ${(ms % 60_000) / 1000}s\n\nReturn to your focus task. Your reward is waiting!"
            handler.postDelayed(this, 1000)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER; setPadding(32,32,32,32); setBackgroundColor(Color.rgb(15,23,42)) }
        layout.addView(TextView(this).apply { text = "FOCUS TIME"; textSize = 30f; setTextColor(Color.rgb(134,239,172)) })
        message = TextView(this).apply { textSize = 19f; gravity = android.view.Gravity.CENTER; setTextColor(Color.WHITE); setPadding(0,30,0,30) }
        layout.addView(message)
        layout.addView(Button(this).apply { text = "BACK TO FOCUS"; setOnClickListener { finish() } })
        setContentView(layout)
        handler.post(tick)
    }
    override fun onResume() { super.onResume(); handler.removeCallbacks(tick); handler.post(tick) }
    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() { if (!FocusStore.isActive(this)) super.onBackPressed() else Toast.makeText(this, "Strict Mode ends when the timer expires.", Toast.LENGTH_SHORT).show() }
}
