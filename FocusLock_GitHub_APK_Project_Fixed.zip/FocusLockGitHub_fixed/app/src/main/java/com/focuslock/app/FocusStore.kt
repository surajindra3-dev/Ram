package com.focuslock.app

import android.content.Context

object FocusStore {
    private const val PREF = "focus_lock_store"
    private const val END = "session_end"
    private const val SELECTED = "selected_packages"
    private const val AWARDED_END = "awarded_end"
    private const val POINTS = "points"
    private const val COMPLETED = "completed_sessions"

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun endAt(c: Context) = p(c).getLong(END, 0L)
    fun isActive(c: Context) = System.currentTimeMillis() < endAt(c)
    fun remainingMs(c: Context) = (endAt(c) - System.currentTimeMillis()).coerceAtLeast(0L)
    fun selected(c: Context): Set<String> = p(c).getStringSet(SELECTED, emptySet())?.toSet() ?: emptySet()
    fun saveSelected(c: Context, items: Set<String>) { p(c).edit().putStringSet(SELECTED, items).apply() }
    fun start(c: Context, minutes: Int) {
        p(c).edit().putLong(END, System.currentTimeMillis() + minutes * 60_000L).apply()
    }
    fun awardIfFinished(c: Context) {
        val end = endAt(c)
        if (end == 0L || System.currentTimeMillis() < end) return
        val prefs = p(c)
        if (prefs.getLong(AWARDED_END, 0L) != end) {
            prefs.edit().putLong(AWARDED_END, end)
                .putInt(POINTS, prefs.getInt(POINTS, 0) + 10)
                .putInt(COMPLETED, prefs.getInt(COMPLETED, 0) + 1).apply()
        }
    }
    fun points(c: Context) = p(c).getInt(POINTS, 0)
    fun completed(c: Context) = p(c).getInt(COMPLETED, 0)
}
