package com.focuslock.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val socialPackages = setOf(
        "com.instagram.android", "com.facebook.katana", "com.facebook.orca",
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.twitter.android",
        "com.x.android", "com.snapchat.android", "com.reddit.frontpage",
        "com.google.android.youtube", "com.pinterest", "com.linkedin.android",
        "com.discord", "com.whatsapp", "org.telegram.messenger"
    )
    private val checks = mutableMapOf<String, CheckBox>()
    private lateinit var status: TextView
    private lateinit var timer: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() { super.onResume(); FocusStore.awardIfFinished(this); updateStatus() }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 28, 28, 28); setBackgroundColor(Color.rgb(15, 23, 42)) }
        fun text(s: String, size: Float = 16f, color: Int = Color.WHITE) = TextView(this).apply { text = s; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10) }
        root.addView(text("FOCUS LOCK", 27f))
        root.addView(text("Offline focus sessions · Rewards · App blocking", 14f, Color.LTGRAY))
        status = text("", 16f, Color.rgb(134, 239, 172)); root.addView(status)
        root.addView(text("Choose apps to block", 19f))
        root.addView(text("Social apps are preselected when installed. Keep Phone, Messages, Maps and emergency apps available.", 13f, Color.LTGRAY))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pm = packageManager
        val apps = try { pm.getInstalledApplications(0).filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }.sortedBy { pm.getApplicationLabel(it).toString().lowercase() } } catch (_: Exception) { emptyList() }
        val saved = FocusStore.selected(this)
        apps.forEach { app ->
            val name = pm.getApplicationLabel(app).toString()
            val cb = CheckBox(this).apply {
                text = name; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(134,239,172))
                isChecked = if (saved.isEmpty()) socialPackages.contains(app.packageName) else saved.contains(app.packageName)
                isEnabled = !FocusStore.isActive(this@MainActivity)
            }
            checks[app.packageName] = cb; list.addView(cb)
        }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("Session duration", 17f))
        timer = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("25 minutes", "50 minutes", "90 minutes", "120 minutes")) }
        root.addView(timer)
        val start = Button(this).apply { text = "SAVE APPS & START STRICT SESSION"; setOnClickListener { startSession() } }
        root.addView(start)
        val access = Button(this).apply { text = "ENABLE APP-BLOCKING ACCESSIBILITY"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        root.addView(access)
        root.addView(text("🏆 Rewards: ${FocusStore.points(this)} points  ·  ${FocusStore.completed(this)} completed sessions", 16f, Color.rgb(250,204,21)))
        setContentView(root); updateStatus()
    }

    private fun startSession() {
        if (FocusStore.isActive(this)) { Toast.makeText(this, "Strict session is already running.", Toast.LENGTH_SHORT).show(); return }
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Please enable Focus Lock accessibility service first.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        val selected = checks.filterValues { it.isChecked }.keys
        if (selected.isEmpty()) { Toast.makeText(this, "Select at least one app to block.", Toast.LENGTH_SHORT).show(); return }
        FocusStore.saveSelected(this, selected)
        val minutes = listOf(25, 50, 90, 120)[timer.selectedItemPosition]
        FocusStore.start(this, minutes)
        Toast.makeText(this, "Strict focus session started. +10 points after completion.", Toast.LENGTH_LONG).show()
        render()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == packageName && it.resolveInfo.serviceInfo.name == FocusAccessibilityService::class.java.name
        }
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        val ms = FocusStore.remainingMs(this)
        status.text = if (ms > 0) "STRICT MODE ACTIVE · ${(ms / 60_000)}m ${((ms % 60_000) / 1000)}s remaining" else "STRICT MODE OFF · Ready for a new session"
    }
}
