package com.focuslock.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {
    private var lastBlockedPackage: String? = null
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !FocusStore.isActive(this)) { FocusStore.awardIfFinished(this); lastBlockedPackage = null; return }
        val pkg = event.packageName?.toString() ?: return
        // Never interfere with Android system UI, settings, dialer, emergency calling, or Focus Lock itself.
        val safe = setOf(packageName, "com.android.settings", "com.android.systemui", "com.google.android.dialer", "com.android.dialer", "com.android.phone")
        if (pkg in safe || pkg.startsWith("com.android.permissioncontroller")) return
        if (pkg in FocusStore.selected(this) && lastBlockedPackage != pkg) {
            lastBlockedPackage = pkg
            val i = Intent(this, BlockedActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("blocked_app", pkg)
            }
            try { startActivity(i) } catch (_: Exception) { }
        } else if (pkg !in FocusStore.selected(this)) lastBlockedPackage = null
    }
    override fun onInterrupt() { lastBlockedPackage = null }
}
