# FocusLock — Android APK project

This project builds a debug APK with GitHub Actions. It intentionally does **not** rely on `gradlew`; the workflow downloads Gradle 8.9 on the GitHub runner and runs the build with JDK 17.

## Upload to GitHub

1. Extract this ZIP.
2. Open the extracted `FocusLockGitHub_fixed` folder.
3. Upload **the contents of this folder** to the root of your GitHub repository (not the folder itself). Keep `.github/workflows/android.yml` in place. On mobile GitHub, enable “Show hidden files” if needed so `.github` is included.
4. Make sure the repository's default branch is `main`, or change the branch name in `.github/workflows/android.yml`.
5. Open **Actions** → **Android CI** → **Run workflow**. A push to `main` also starts a build.
6. When successful, open the workflow run and download the `FocusLock-debug-apk` artifact.

## App setup

Install the debug APK, open FocusLock, grant its Accessibility Service in Android Settings, select the apps to block, then start a focus session. Focus data and reward points are stored locally on the device.

## Important limitations

Blocking uses Android Accessibility Service and requires the user to enable it. An ordinary app cannot guarantee an unbreakable lock against the device owner: Android still permits revoking Accessibility access, force-stopping/uninstalling the app, or using system-level controls. Essential system, emergency, and permission screens are intentionally not blocked. This is not a device-owner kiosk app.

The workflow change fixes the specific missing-`gradlew` failure shown in the provided GitHub Actions log. It does not claim that a remote GitHub build has already been run or passed.
